<section class="newsletter">
				<div class="container">
          <h3>Email Newsletter Sign-Up</h3>
          <form>
            <div class="name-email">
							<div class="name">
								<label for="name">Your Name </label>
								<input type="text" id="name" name="name">
							</div>
							<div class="email">
								<label for="email">Your Email </label>
								<input type="email" id="email">
							</div>
            </div>
            <div class="checkbox">
              <input type="checkbox">
              <span class="checkmark"></span>
              <p>Please tick this box if you wish to receive marketing information from us. Please see our <a href="#">Privacy Policy</a> for more information on how we keep your data safe.</p>
            </div>
            <div class="subscribe">
              <input type="submit" value="Subscribe">
            </div>
          </form>
        </div>
			</section>