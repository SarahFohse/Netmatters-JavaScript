<div class="message">
  <button type="button"><i class="fa-solid fa-message"></i></button>
</div>
<div class="consent">
  <button type="button" id="consent-btn">Manage Consent</button>
</div>